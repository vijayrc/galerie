cd /home/vijayrc/tools/galerie
java -jar layer.jar
