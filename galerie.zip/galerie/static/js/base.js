/*---------------------------------------|STORE|------------------------------------------------*/
Store = function(){
    var paths = ['/home/vijayrc/pics/wallpapers'];

    this.addPath = function(path){
        paths.push(path);
        localStorage.removeItem('paths');
        localStorage['paths'] = JSON.stringify(paths);
    };
    this.getPaths = function(){
        return JSON.parse(localStorage['paths']);
    };
    this.flushPaths = function(){
        localStorage.removeItem('paths');
    };
};
var store = new Store();
/*---------------------------------------|PATH|------------------------------------------------*/
AutoPath = function(){
    this.make = function(){
       $('#root-txt').autocomplete({source: store.getPaths()});
    };
    this.update = function(response){
       response.find('li').each(function(){store.addPath($(this).text());});
    };
    this.flush = function(){
        store.flushPaths();
    };
};
/*---------------------------------------|THUMBS|---------------------------------------------*/
Thumbs = function(){
    var player = new Player();
    var box = $('#box');
    var count = 0;
    var current = 0;
    var fetchFlag = false;

    this.fromFolder = function(){
        this.fetch('/galerie/thumbs/');
    };
    this.search = function(){
        this.fetch('/galerie/search/');
    };

    this.fetch = function(url){
       var root = $('#root-txt').val();
       if(root.length == 0 || fetchFlag) {
           $('#root-txt').attr("placeholder","input needed");
           return;
       }
       box.hide();
       $('#thumbs').html("<h1 style='padding:1%;'>fetching files, please wait..</h1>");
       $("#media").dialog("destroy");
       fetchFlag = true;
       $.ajax({url : url, type : "GET", data:{root:root}})
           .done(function(response){
               $('#thumbs').html(response);
               current = 0;
               count = $('.thumb').length;
               $('#root-btn').click();
               store.addPath(root);
               autoPath.make();
               setup();
               player.setup();
               fetchFlag = false;
       });
    };
    var setup = function(){
        var box = $('#box');
        $('.thumb').each(function(){
            $(this).click(function(){
                var img = $(this).children('img');
                var boxImg = $('.box-img');
                box.show('slide', 400);
                box.attr('title',img.attr('description'));
                boxImg.attr('src',img.attr('orig'));
                boxImg.css('max-height',0.97*window.innerHeight);

                var style = $(this).attr('style');
                var boxStyle = box.attr('style');
                if(style && boxStyle){
                    var topPosition = $(this).attr('style').match(/top: ([0-9]{1,5}px)/);
                    var boxStyle = boxStyle.replace(/top: [0-9]{1,5}px/,topPosition[0]);
                    box.attr('style',boxStyle);
                }
            });
            $(this).hover(
               function() {$(this).addClass("thumb-select");},
               function() {$(this).removeClass("thumb-select");}
            );
        });
        $('.thumb-count').html(count+"<span style='font-size:40%'>nos</span>");
        $('#gallery').imagesLoaded( function() {
          $('#gallery').packery({itemSelector: '.thumb', gutter: 1,isResizeBound:true});
        });
    };
    this.selectOnRight = function(){
        if(current < count) current++;
        else current = 0;
        updateSelectedThumb();
    };
    this.selectOnLeft = function(){
        if(current > 0) current--;
        else current = count;
        updateSelectedThumb();
    };
    var updateBox = function(selectedThumb){
        if($('.box-img')){
            var box = $('#box');
            var selectedImg = selectedThumb.children('img');
            $('.box-img').attr('src',selectedImg.attr('orig'));
            box.attr('title',selectedImg.attr('description'));
            fitImgHeight();
        }
    };
    var updateSelectedThumb = function(){
        $('.thumb-select').removeClass('thumb-select');
        var selectedThumb = $($('.thumb')[current]);
        selectedThumb.addClass('thumb-select');
        updateBox(selectedThumb);
    };
    var fitImgHeight = function(){
        $('.box-img').css('max-height',0.97*window.innerHeight);
    };
    var flexImgHeight = function(){
        $('.box-img').css('max-height',0.97*document.height);
    };
};

/*----------------------------------------|OPENER|-----------------------------------------------------*/
Player = function(){
   this.setup = function(){
      $('.file-link').click(function(){
          var path = $(this).attr('path');
          $.ajax({url : "/galerie/play/",type : "GET",data:{path:path}})
          .done(function(response){$('#player_msg').html(response);});
      });
      $('#player_msg').html('');
      this.dialog();
   };
   this.dialog = function(){
      if($("#media").length == 0) return;
      $("#media").dialog({
        autoOpen: true,
        closeOnEscape: true, draggable: true,
        width:1000, maxHeight:800,
        appendTo: "#thumbs",
        show: { effect: "slideDown", duration: 300 },
        hide: { effect: "slideUp", duration: 300 },
        position: { my: "right top", at: "right top", of: window }
      });
      setTimeout(function() {
        $('#file-types').packery({itemSelector: '.file-type', gutter: 1,isResizeBound:true});
      }, 1500);
   };

};
/*----------------------------------------|SCROLLER|-----------------------------------------------------*/
Scroller = function(){
    var trackers = {};

    this.follow = function(target){
        trackers[target.attr('id')] = true;
        var target_pos_original = target.offset().top;
        $(window).scroll(function(){
            if(!trackers[target.attr('id')])
                return;
            var target_pos = target.offset().top;
            var window_pos = $(window).scrollTop();
            var final_pos = window_pos;
            if(window_pos<target_pos_original) {
                final_pos = target_pos_original;
                target.stop().css({'top':10});
            } else {
                target.stop().animate({'top':final_pos-target_pos_original+10},500);
            }
        });
    };
    this.lock= function(target){
        trackers[target.attr('id')] = false;
    };
    this.unlock= function(target){
        trackers[target.attr('id')] = true;
    };
};
/*----------------------------------------|HOMEPAGE|------------------------------------------------*/
HomePage = function(){
    var popHtml = '<form id="rootForm">'
    +'<input id="root-txt" type="text" class="form-control" onLoad="setFocus()" style="width:400px;color:black;font-size:85%;" onkeypress="rootKeyPress(event)">'
    +'<button style="width:10%;margin-top:2%;" onclick="rootSet()" type="button" class="form-control btn btn-default btn-sm">'
    +'<span class="glyphicon glyphicon-tag"></span>'
    +'</button>'
    +'<button style="width:10%;margin-top:2%;" onclick="rootFlush()" type="button" class="form-control btn btn-default btn-sm">'
    +'<span class="glyphicon glyphicon-trash"></span>'
    +'</button>'
    +'<button style="width:10%;margin-top:2%;" onclick="rootIndex()" type="button" class="form-control btn btn-default btn-sm">'
    +'<span class="glyphicon glyphicon-pushpin"></span>'
    +'</button>'
    +'<button id="find_btn" style="width:10%;margin-top:2%;" onclick="rootSearch()" type="button" class="form-control btn btn-default btn-sm">'
    +'<span class="glyphicon glyphicon-search"></span>'
    +'</button>'
    +'<span id="pop_res" style="font-size:80%;padding-left:4%;"></span>'
    +'</form>';

    var helpHtml = '<ul class="helper">'
    +'<li>[f2]=folder open</li>'
    +'<li>[f4]=pack thumbs</li>'
    +'<li>[f6]=stop server</li>'
    +'<li>[f8]=shortcut keys</li>'
    +'<li>[+]=lock image</li>'
    +'<li>[-]=unlock image</li>'
    +'<li>[<]=minimize image</li>'
    +'<li>[>]=maximize image</li>'
    +'<li>[esc]=close overlays</li>'
    +'</ul>'

    var scroller = new Scroller();
    var player = new Player();
    var box =  $('#box');

    var showHomePopup = function(){
        $('#box').hide();
        $('#root-txt').focus();
        $('#pop_res').html('');
    };
    var maximise = function(){
        var width = box.width();
         $('.box-img').css('max-height',0.97*document.height);
        box.animate({width:width*1.1},50);
    };
    var minimise = function(){
        var width = box.width();
        box.animate({width:width*0.9},50);
    };
    var setupButtons = function(){
        $('#pack-btn').click(function(){$('#gallery').packery({itemSelector: '.thumb', gutter: 1,isResizeBound:true});});
        $('#logo-btn').click(function(){$('#thumbs').html('<img src="/static/images/end.png" alt="end">')});
        $('#help-btn').popover({html:'true',content:helpHtml});
        $('#media-btn').click(function(){player.dialog();});
        $('#root-btn').popover({html:'true',content:popHtml});
        $('#root-btn').click(showHomePopup);
        $('#stop-btn').click(function(){
            $.ajax({url : "/stop",type : "GET"}).done(function(response){$('#thumbs').html(response);});
        });
    };
    var setupBox = function(){
        box.hide();
        $('.box-img').click(function(){box.hide('slide',400)});
        $('.box-lock').click(function(){scroller.lock(box);});
        $('.box-unlock').click(function(){scroller.unlock(box);});
        $('.box-max').click(maximise);
        $('.box-min').click(minimise);
        scroller.follow(box);
    };
    var closeAllDialogs = function(){
        box.hide('slide',400);
        if($('#root-txt').length !=0) $('#root-btn').click();
        if($('.helper').length !=0) $('#help-btn').click();
        if($('#media').length !=0)$('#media').dialog('close');
    };
    var setupKeys = function(e){
        switch(e.keyCode) {
            case 37:
                thumbs.selectOnLeft();
                break;
            case 39:
                thumbs.selectOnRight();
                break;
            case 188:
                minimise();
                break;
            case 190:
                maximise();
                break;
            case 27:
                closeAllDialogs();
                break;
            case 113:
                $('#root-btn').click();
                break;
            case 115:
                $('#pack-btn').click();
                break;
            case 117:
                closeAllDialogs();
                $('#stop-btn').click();
                break;
            case 118:
                thumbs.search();
                break;
            case 119:
                $('#help-btn').click();
                break;
            case 121:
                $('#media-btn').click();
                break;
            case 187:
                $('.box-lock').click();
                break;
            case 189:
                $('.box-unlock').click();
                break;
            case 16:
                if($('.thumb-select'))
                    $('.thumb-select').click();
                break;
        }
    };
    this.boot = function(){
        setupBox();
        setupButtons();
        window.addEventListener("keydown", setupKeys, false);
    };
};
/*---------------------------------------------|SIMPLE FUNCTIONS|------------------------------------------------*/
var autoPath = new AutoPath();
var thumbs = new Thumbs();

rootKeyPress = function(event){
    if(event.keyCode == 13){
       thumbs.fromFolder();
       event.preventDefault();
    }else{
       autoPath.make();
    }
};
rootSet = function(){
    $.ajax({url : "/galerie/paths/",type : "GET", data:{root:$('#root-txt').val()}})
   .done(function(response){autoPath.update($(response)); $('#pop_res').html('added all nested folders to autocomplete');});
};
rootIndex = function(){
    $.ajax({url : "/galerie/index/",type : "GET", data:{root:$('#root-txt').val()}})
   .done(function(response){$('#pop_res').html(response);});
};
rootSearch = function(){
    thumbs.search();
};
rootFlush = function(){
    autoPath.flush();
    $('#pop_res').html('removed all nested folders to autocomplete');
};
setFocus = function(){
   $(this).focus();
};

/*---------------------------------------------|BOOT|------------------------------------------------*/
$(document).ready(function() {
    new HomePage().boot();
});
